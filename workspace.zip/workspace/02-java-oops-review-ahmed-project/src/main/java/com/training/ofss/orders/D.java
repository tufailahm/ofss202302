package com.training.ofss.orders;

import com.training.ofss.model.A;

public class D {
		public void display() {
			A a = new A();
			System.out.println(a.num);
		}
}
