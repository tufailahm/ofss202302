package com.training.ofss.model;

public class C {
		public void display() {
			A a = new A();
			System.out.println(a.num);

		}
}
