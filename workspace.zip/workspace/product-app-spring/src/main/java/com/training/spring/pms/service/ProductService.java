package com.training.spring.pms.service;

import com.training.spring.pms.model.Product;

public interface ProductService {
		public void saveProduct(Product product);
		public void updateProduct(Product product);
}
