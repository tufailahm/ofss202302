package com.training.spring.pms.dao;

public class Message {

	public Message() {
		// TODO Auto-generated constructor stub
	}
	public void sayHello() {
		System.out.println("Hi from message");
	}
}
