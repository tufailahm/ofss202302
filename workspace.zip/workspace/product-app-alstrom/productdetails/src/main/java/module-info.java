module productdetails {
	requires productlist;

}