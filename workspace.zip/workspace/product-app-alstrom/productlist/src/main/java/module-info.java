module productlist {
	exports com.training.plist;
}