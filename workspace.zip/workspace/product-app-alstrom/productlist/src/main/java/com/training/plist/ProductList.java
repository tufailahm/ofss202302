package com.training.plist;

import java.util.ArrayList;
import java.util.List;

public class ProductList {
		
	public static List<String> getProductList() {
		List<String> products = new ArrayList();
			products.add("Lakme");
			products.add("Aroma");
			products.add("Glass");
			return products;
	}
}
