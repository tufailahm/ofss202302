package com.training.demo1.traditional;
public class RoboCall {

	public static void robocall(String number) {
		/*
		 * Code to place an automated call. This code will connect to the phone system
		 * using the supplied number and place the call.
		 */
		System.out.println("Calling :"+number );
	}

}