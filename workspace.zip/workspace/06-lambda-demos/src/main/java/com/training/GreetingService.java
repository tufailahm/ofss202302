package com.training;

interface GreetingService {
	void sayMessage(String message, String name);
}
