package com.training.demo3.lambda;

import com.training.model.Person;

public interface EligiblePerson {
	boolean isEligible(Person p);
}


