package com.training;

interface MathOperation {
	int operation(int a, int b);
}
