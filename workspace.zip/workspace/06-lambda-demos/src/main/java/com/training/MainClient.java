package com.training;

public class MainClient {

	public static void main(String[] args) {
		GreetingService gs = (m,n) -> System.out.println(m+ " message is from : "+n);
		

	}

}
