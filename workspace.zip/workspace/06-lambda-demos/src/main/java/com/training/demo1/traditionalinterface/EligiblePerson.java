package com.training.demo1.traditionalinterface;

import com.training.model.Person;

public interface EligiblePerson {
	boolean isEligible(Person p);
}


