package com.training.demo2.anonymous;

import com.training.model.Person;

public interface EligiblePerson {
	boolean isEligible(Person p);
}


