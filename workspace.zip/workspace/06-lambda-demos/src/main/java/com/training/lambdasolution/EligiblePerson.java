package com.training.lambdasolution;

import com.training.model.Person;

public interface EligiblePerson {
	boolean isEligible(Person p);
}


