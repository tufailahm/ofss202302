package com.training.ord;

import com.training.reviews.Reviews;

public class OrderDetails {

	public static void main(String[] args) {
			System.out.println(Reviews.getReview(12121));
	}
}
