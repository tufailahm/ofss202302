package com;

public class Calculator {

	public Calculator() {
		// TODO Auto-generated constructor stub
	}
	public int addNumbers(int num1,int num2) {
		return num1+num2;
	}
}
