package com.training.pms.marvel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		
		String un = request.getParameter("username");
		String pass = request.getParameter("password");
		
		//code to check the validity of the user
		//we are assuming the valid user
		pw.println("1. Welcome in LoginController and you are validated "+un);
		//pw.print("Your password is :"+pass);
		//pw.print("<br/><br/><br/><a href=DashboardController>Dashboard</a>");
		if(un.startsWith("T"))
		{
			RequestDispatcher rd = request.getRequestDispatcher("DashboardController");
			rd.forward(request, 	response);
		}
		else if(un.equalsIgnoreCase("utkarsh"))
		{
			RequestDispatcher rd = request.getRequestDispatcher("AdminDashboardController");
			rd.include(request, response);
		}
		else {
			response.sendRedirect("login.html");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
