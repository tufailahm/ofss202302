package com.training.ofss.model;

public class B extends A{
		public void display() {
			A a = new A();
			System.out.println(a.num);
			System.out.println(num);
		}
}
