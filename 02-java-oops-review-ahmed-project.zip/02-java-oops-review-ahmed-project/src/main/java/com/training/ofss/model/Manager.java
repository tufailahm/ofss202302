package com.training.ofss.model;

public class Manager extends Employee{
	
	public void display() {
		System.out.println(super.getName());
	}
}