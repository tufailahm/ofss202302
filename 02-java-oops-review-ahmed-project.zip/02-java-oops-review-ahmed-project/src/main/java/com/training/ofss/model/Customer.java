package com.training.ofss.model;

public class Customer {
		public void payBill() {
			System.out.println("Customer pays the bill");
		}
}
