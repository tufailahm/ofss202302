package com.training.ofss.orders;

import com.training.ofss.model.Demo;

public class CustomerOrders {
	public void payBill() {
		Demo d = new Demo();
		System.out.println("Customer  odrers and pays the bill age is : "+d.age);
	}
}
